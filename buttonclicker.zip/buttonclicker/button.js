
function deleteButton(el){
el.remove();
}
function logOut(element) {
    element.innerText = "Logout";
}
