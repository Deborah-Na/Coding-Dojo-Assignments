function message(){
    alert("Loading weather report...")
}

function disappear(el){
    var toVanish = document.getElementById("cookie");
    toVanish.remove();
}