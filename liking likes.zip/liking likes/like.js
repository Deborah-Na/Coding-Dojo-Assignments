var count = 9;
var neil = document.querySelector("#inc")

function clickMe(){
    count++
    neil.innerText= count + " like(s)";
}

var counting = 12;
var nicole = document.querySelector("#up")

function clickLike(){
    counting++
    nicole.innerText= counting + " like(s)";
}

var counts = 9;
var jim = document.querySelector("#more")

function clickAgain(){
    counts++
    jim.innerText= counts + " like(s)";
}

